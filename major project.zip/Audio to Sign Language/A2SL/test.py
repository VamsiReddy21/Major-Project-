import nltk
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')